# Security tests
Adversarial tests for prompt injection, SSRF, authorization bypass, secret leakage and unsafe tool use.
