## Summary
- 

## Security impact
- [ ] No security impact
- [ ] Security-sensitive change (describe below)

## Verification
- [ ] Tests pass
- [ ] Security checks pass
- [ ] No secrets or credentials added
- [ ] External inputs are validated

## Notes
