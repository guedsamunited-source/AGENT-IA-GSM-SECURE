# Research agent
Collects candidate information from explicitly permitted sources.
