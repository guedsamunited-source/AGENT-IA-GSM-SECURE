# Orchestrator
Coordinates agents without inheriting unrestricted permissions.
