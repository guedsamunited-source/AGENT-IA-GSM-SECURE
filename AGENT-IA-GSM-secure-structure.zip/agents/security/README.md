# Security agent
Runs policy and adversarial checks before privileged actions or final output.
