# Verification agent
Cross-checks important claims independently before trusted output.
