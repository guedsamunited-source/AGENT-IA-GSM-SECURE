# Source agent
Checks provenance, origin, timestamps and source reliability metadata.
