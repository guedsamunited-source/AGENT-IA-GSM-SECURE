# Analysis agent
Performs domain-specific analysis on validated inputs.
