# Tool policy

Tools are deny-by-default. Each tool must have:
- a stable identifier
- explicit input schema
- validation rules
- permitted agents
- permitted destinations
- timeout and resource limits
- audit event definition
