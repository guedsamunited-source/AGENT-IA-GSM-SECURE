# Security policies

Central location for:
- input validation
- output validation
- prompt-injection handling
- SSRF/network restrictions
- secret redaction
- agent authorization
- provenance requirements
