# Agent configuration

Each agent should declare:
- purpose
- allowed tools
- allowed data classes
- network destinations
- maximum execution budget
- escalation conditions
- output schema

Default policy: deny unless explicitly allowed.
