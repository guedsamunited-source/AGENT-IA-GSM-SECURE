# Contributing

## Required
1. Keep changes focused.
2. Never commit secrets.
3. Add tests for security-sensitive behavior.
4. Preserve least-privilege boundaries.
5. Treat external content as untrusted.
6. Use pull requests for review.

## Agent changes
Any new tool, permission, network destination, credential, or inter-agent capability must be explicitly documented and reviewed.
