# AGENT-IA-GSM

Secure multi-agent AI architecture.

## Security objectives
- Least privilege for agents and tools.
- Explicit tool allowlists.
- Isolation between agents.
- Validation of external input and model output.
- Source verification before trusted presentation.
- Audit logging without secrets.
- Protection against prompt injection, SSRF and unsafe tool execution.
- Reproducible CI checks and dependency review.

## Architecture
`orchestrator` coordinates specialized agents through a constrained protocol.
`research` gathers information.
`source` verifies provenance.
`verification` cross-checks claims.
`analysis` performs domain analysis.
`security` applies policy and adversarial checks.

No agent should receive unrestricted access to the network, filesystem, credentials, or arbitrary command execution.
