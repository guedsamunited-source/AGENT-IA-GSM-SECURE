# Threat model

Primary threats:
1. Prompt injection through web pages/documents.
2. SSRF via model-controlled URLs.
3. Secret leakage through prompts, logs or tool outputs.
4. Privilege escalation between agents.
5. Malicious or compromised dependencies.
6. Unsafe code/command execution.
7. False provenance or stale source data.

Mitigations are implemented as defense in depth: deny-by-default permissions, URL/domain allowlists, schema validation, isolation, redaction, provenance checks, bounded execution, dependency review and adversarial testing.
