# Architecture overview

The orchestrator delegates bounded tasks to specialized agents. Agents communicate through a structured protocol. External information is considered untrusted until provenance and validation checks pass. Privileged actions require explicit authorization and policy validation.
