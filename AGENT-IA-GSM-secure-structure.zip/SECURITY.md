# Security Policy

## Principles
Security issues should be reported privately when they could expose credentials, user data, remote code execution, unauthorized access, or other sensitive impact.

## Rules
- Never commit API keys, tokens, passwords, private keys, cookies, or production credentials.
- Use least-privilege credentials and short-lived tokens where possible.
- Validate and constrain all external URLs and tool parameters.
- Treat web content and retrieved documents as untrusted input.
- Do not allow model-generated text to directly become privileged tool arguments without validation.
- Keep agent-to-agent messages structured, authenticated where applicable, bounded in size, and policy checked.
- Log security-relevant events while redacting secrets and personal data.

## Threat model
The system assumes hostile or misleading web content, prompt injection, malicious documents, compromised dependencies, and accidental operator mistakes.

## Disclosure
Provide a minimal reproducible description, affected component, impact, and reproduction steps through a private security channel configured by the repository owner.
