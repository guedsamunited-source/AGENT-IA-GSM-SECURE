# Shared
Non-sensitive shared types and utilities.
