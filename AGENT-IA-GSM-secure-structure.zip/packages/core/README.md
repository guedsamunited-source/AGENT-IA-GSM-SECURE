# Core
Shared application primitives.
