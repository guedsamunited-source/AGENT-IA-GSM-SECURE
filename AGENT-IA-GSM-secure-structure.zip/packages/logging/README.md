# Audit logging
Security-relevant structured events with secret and sensitive-data redaction.
