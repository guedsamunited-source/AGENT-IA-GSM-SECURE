# Agent protocol
Structured, bounded inter-agent messages; no unrestricted free-form privilege delegation.
