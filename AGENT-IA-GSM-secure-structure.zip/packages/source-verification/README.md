# Source verification
Provenance and freshness checks for external information.
